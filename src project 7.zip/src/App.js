import logo from './logo.svg';
import './App.css';
import Home from './component/Index'
import Form from './component/Form'
const google=window.google
function App() {
  return (
    <Home />  );
}

export default App;
